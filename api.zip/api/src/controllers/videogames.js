const axios = require("axios")
require('dotenv').config();
const {APIKEY} = process.env
const {Videogame, Genre} = require("../db")
const { sequelize } = require('sequelize');


//GetAllVideogames = 
//Controladores
const getApiGames = async () => {
    const apiUrl = await axios.get(`https://api.rawg.io/api/games?key=${APIKEY}`);
    console.log(apiUrl)
    const apiGames = await apiUrl.data.results?.map(game => {
        return {
            id: game.id,
            name: game.name,
            description: game.ratings.map(description => description.title),
            releaseDate: game.released,
            rating: game.rating,
            platforms: game.platforms?.map((p) => p.platform.name),
            image: game["background_image"]
        }
        
    });
    console.log(apiGames)
    return apiGames
}

const getDbGames = async () =>{
    const dbGames = await Videogame.findAll({
        include : {
            model: Genre,
            attributes: ["name"],
            through: {
                attributes: [],
                },
            }
    });
    return dbGames
}

const getAllGames = async () =>{
    const apiGames = await getApiGames();
    const dbGames = await getDbGames();
    const allGames = apiGames.concat(dbGames);

    return allGames
}




module.exports = {getApiGames, getDbGames, getAllGames}
