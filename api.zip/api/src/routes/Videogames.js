const {Router} = require("express")
const {getApiGames, getDbGames, getAllGames} = require("../controllers/videogames")
const {APIKEY} = process.env
const axios = require("axios")
const {Videogame, Genre} = require("../db")

const router = Router();



//ARMAR UN ARRAY PARA ACOMODAR LOS JUEGUITOS??
//--------> Controllers



//--------->Rutas

router.get("/", async (req, res) =>{
        try {
            const name = req.query.name
            //let allVideogames = await getAllGames();
            
            const apiUrl = await axios.get(`https://api.rawg.io/api/games?key=${APIKEY}`);
            console.log(apiUrl)
            const apiGames = await apiUrl.data.results?.map(game => {
                return {
                    id: game.id,
                    name: game.name,
                    description: game.ratings.map(description => description.title),
                    releaseDate: game.released,
                    rating: game.rating,
                    platforms: game.platforms?.map((p) => p.platform.name),
                    image: game["background_image"]
                }
                
            });
            console.log(apiGames)
            res.status(200).json(apiGames)
                // if(name){
                //     let videogameByName = await allVideogames.filter(game => game.name.toLowerCase().includes(name.toLowerCase()));
                //     videogameByName.length?
                //     res.status(200).send(videogameByName):
                //     res.status(404).send("The game youre searching for does not exist")
                // } else{
                //     res.status(200).send(allVideogames)
             //   }
        } catch (error) {
            res.status(400).send(error.message)
        }
});





router.get("/videogames/id:idvideogame", async (req, res) => {

    try {
        
    } catch (error) {
        
    }

})


router.post("/videogames", (req, res) => {

    try {
        
    } catch (error) {
        
    }

})


module.exports = router;