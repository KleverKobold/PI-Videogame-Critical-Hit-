const {Router} = require("express")
const router = Router();


router.get("/genres", async (req, res) => {

    try {
        
    } catch (error) {
        
    }

})